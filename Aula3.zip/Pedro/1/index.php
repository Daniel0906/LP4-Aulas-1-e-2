<?php

//VARIÁVEIS - CONTINUAÇÃO

$nome = "Pedro"; #String
$aula = 'PHP';   #String
$idade = 19;     #int
$peso = 70.5;    #float
$altura = 1.71;  #float

// UTILIZANDO AS VARIÁVEIS

echo "Utilizando as variáveis <br><br>";
echo "Meu nome: $nome <br>";
echo 'Minha idade: $idade <br>';
echo "Minha idade: $idade <br><br>";
// CONCATEAÇÃO DE STRING COM '.'

echo "Meu peso: $peso <br>";
echo "Minha altura: $altura <br><br>";

// VER 2 UTILIZANDO AS VARIÁVEIS

echo "Meu nome é $nome, tenho $idade anos de idade. <br>";
echo "Meu peso e minha altura são respectivamente $peso e $altura.";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TESTE</title>
</head>
<body>
    
</body>
</html>