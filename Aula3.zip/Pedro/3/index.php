<?php

// VARIÁVEIS - CONTINUAÇÃO 3

# Trabalhando com CONSTANTES
# São utilizadas cp, variáveis cujo conteúdo não devem mudar.
# Como padrão são definidas com letras maiúsculas.

echo "Trabalhando com Constantes <p>";

// EXEMPLOS
# Definindo uma variável constante de nome TAXA com 50%
define("TAXA", 0.5);

# Definindo outra variável constante de nome JUROS com 1%
define("JUROS", 0.01);

// UTILIZANDO ESSAS VARIÁVEIS
echo "Valor da taxa: " . TAXA . "%<br>";
echo "Valor do juros igual a: " . JUROS . "%<br>";



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TESTE</title>
</head>
<body>
    
</body>
</html>