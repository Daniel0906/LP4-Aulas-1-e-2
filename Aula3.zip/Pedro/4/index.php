<?php

// FORMATAÇÃO DE VARIÁVEIS NUMÉRICAS
# Utilizando numberFormat()

echo "Formatação de variáveis numéricas <br>";
echo "<br>";

# Definindo variáveis
$Val = 75.5; #float

# Apresentando SEM formatação
echo "1 - Apresentando a variável SEM a formatação <br>";
echo "Valor da variável: $Val <br>";

# Apresentando o tipo da variável
echo "Apresentando o tipo da variável sem a formatação: ";
echo var_dump($Val);
echo "<br><br>";

# Apresentando COM formatação
echo "2 - Apresentando a variável COM a formatação <br>";
$ValFormat = number_format($Val, 2, ',' , '.');
echo "Valor da variável formatada: $ValFormat <br>";

# Apresentando o tipo da variável:
echo "Apresentando o tipo da variável: ";
echo var_dump($ValFormat);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TESTE</title>
</head>
<body>
    
</body>
</html>