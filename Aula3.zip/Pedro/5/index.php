<?php

// TIPOS DE DADOS

# As variáveis podem ser de diferentes tipos de dados
# A mesma variável pode conter tipos diferentes de dados

# Atribuições de tipos diferentes para a mesma variável
$variavel = 100;
$variavel = "cem";

# Apesar das variáveis serem de tipo implícito, é importante conhecer alguns tipos de variáveis
$int = 100;             # São valores seguidos SEM casas decimais
$float = 10.5;          # São valores seguidos de casas decimais
$bool = true; #false    # Assume valores Falso ou Verdadeiro
$string = "Bom dia";    # Cadeia de caracteres
$array = [1,2,3];       # Coleção de valores
$null = null;           # Variável com valor nulo
# $pessoa = new Pessoa();
# Objeto com propriedade e métodos

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TESTE</title>
</head>
<body>
    
</body>
</html>