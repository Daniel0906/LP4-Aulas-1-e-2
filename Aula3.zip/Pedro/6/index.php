<?php

// OPERADORES LÓGICOS - O que é / Operador de atribuição

# São símbolos que permitem executar operações matemáticas, ou operações lógicas/comparativas.

# Parte 1
# Operador de atribuição utilizando o sinal de "="
$var = 100;
echo "1 - Operador de atribuição <br> Valor atribuído: $var <br><br>";

# Parte 2
# Alguns operadores de atribuição
$a = 20;
$b = 10;
$x = $y = $z = 100;

# Alguns Operadores matemáticos

echo "2 - Operadores matemáticos <br><br> a = 20 <br> b = 10 <br><br>";

# Adição
$x = $a + $b;
echo "Adição: $x";
echo "<br>";

# Subtração
$x = $a - $b;
echo "Subtração: $x";
echo "<br>";

# Multiplicação
$x = $a * $b;
echo "Multiplicação: $x";
echo "<br>";

# Divisão
$x = $a / $b;
echo "Divisão: $x";
echo "<br>";

# Módulo (Resto da divisão)
$x = $a % $b;
echo "Módulo: $x";
echo "<br>";









?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>TESTE</title>
</head>
<body>

</body>
</html>