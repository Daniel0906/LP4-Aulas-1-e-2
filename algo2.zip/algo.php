<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variaveis</title>
</head>
<body>
    <center>
        <p>Variaveis em PHP</p>
        <form action="algo2.php" method="POST">
            <p>Nome: <input type="text" name="nome" placeholder="Digite seu nome..." required></p>
            <p>E-mail: <input type="email" name="email" placeholder="Digite seu email..." required></p>
            <p>Telefone: <input type="text" name="telefone" placeholder="Digite seu telefone..." required></p>
            <p>Senha: <input type="password" name="senha" placeholder="Digite sua senha..." required></p>
            <input type="submit" value="enviar">
        </form>
    </center>
</body>
</html>